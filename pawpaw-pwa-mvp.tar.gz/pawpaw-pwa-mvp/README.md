# PawPaw Spa & Clinic - PWA

A comprehensive, mobile-first Progressive Web App for pet spa and clinic management, built with React, TypeScript, and Google services.

## 🚀 Features

### Core Functionality
- **🏠 Home**: Beautiful landing page with service highlights
- **📅 Booking System**: Online appointment booking with real-time availability
- **💉 Vaccination Tracking**: Pet vaccination records and reminders
- **🛍️ Product Catalog**: Browse services and pet products
- **📞 Contact Form**: Integrated contact with email notifications
- **⚙️ Admin Dashboard**: Complete backend management via Google Sheets

### PWA Features
- **📱 Installable**: Works as a native app on iOS/Android
- **🔄 Offline Support**: Core functionality works without internet
- **⚡ Fast Loading**: Optimized for speed and performance
- **🔔 Push Notifications**: Appointment reminders (optional)
- **📲 Responsive**: Perfect on all device sizes

### Technical Features
- **🎨 Modern UI**: Built with Tailwind CSS and shadcn/ui components
- **🔒 Secure**: reCAPTCHA protection and data validation
- **📊 Analytics**: Google Analytics integration ready
- **🔧 Maintainable**: Clean code with TypeScript and React Query

## 🛠 Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** for styling
- **React Router** for navigation
- **React Hook Form** with Zod validation
- **Zustand** for state management
- **TanStack Query** for server state
- **PWA** with vite-plugin-pwa

### Backend
- **Google Apps Script** (serverless functions)
- **Google Sheets** (database)
- **Google Calendar** (appointment scheduling)
- **Gmail** (email notifications)
- **Google Drive** (file storage)

### Deployment
- **Hostinger** (hosting)
- **Free SSL** with Let's Encrypt
- **CDN Ready** for Cloudflare

## 📋 Requirements

### For Development
- Node.js 18+
- npm or yarn
- Google Account
- Modern web browser

### For Deployment
- Hostinger hosting (Premium+ recommended)
- Custom domain (optional)
- Google Account with Sheets/Calendar access

## 🚀 Quick Start

### 1. Clone and Install
```bash
git clone <repository-url>
cd pawpaw-pwa-mvp/app
npm install
```

### 2. Setup Backend
1. Create Google Sheet: [New Sheet](https://sheets.new)
2. Open [Google Apps Script](https://script.google.com)
3. Copy `backend/Code.gs` content
4. Deploy as Web App
5. Copy the Web App URL

### 3. Configure Frontend
```bash
# Copy environment file
cp .env.example .env

# Edit .env with your configuration
VITE_API_BASE_URL=https://script.google.com/macros/s/YOUR_WEB_APP_URL/exec
VITE_RECAPTCHA_SITE_KEY=YOUR_RECAPTCHA_KEY
```

### 4. Run Development
```bash
npm run dev
```

### 5. Build for Production
```bash
npm run build
npm run preview
```

## 📁 Project Structure

```
pawpaw-pwa-mvp/
├── app/                    # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utility functions
│   │   ├── store/         # State management
│   │   └── types/         # TypeScript definitions
│   ├── public/            # Static assets
│   ├── dist/              # Build output
│   └── package.json
├── backend/               # Google Apps Script backend
│   ├── Code.gs           # Main backend logic
│   └── appsscript.json   # Apps Script configuration
├── docs/                 # Documentation
│   ├── DEPLOY.md         # Deployment guide
│   └── ADMIN.md          # Admin guide
├── samples/              # Sample data files
└── README.md
```

## 🔧 Configuration

### Environment Variables
```bash
# API Configuration
VITE_API_BASE_URL=https://script.google.com/macros/s/YOUR_WEB_APP_URL/exec

# reCAPTCHA
VITE_RECAPTCHA_SITE_KEY=YOUR_RECAPTCHA_SITE_KEY

# App Info
VITE_APP_NAME=PawPaw Spa & Clinic
VITE_APP_VERSION=1.0.0
```

### Google Sheet Setup
The backend automatically creates these sheets:
- **CONFIG**: Business settings
- **SERVICES**: Service catalog
- **STAFF**: Staff management
- **BOOKINGS**: Appointment bookings
- **VACCINATIONS**: Pet vaccination records
- **INVENTORY**: Product inventory
- **EMAIL_TEMPLATES**: Email templates
- **LOGS**: System logs

## 📱 PWA Features

### Installation
1. Open the app in Chrome/Safari on mobile
2. Look for "Add to Home Screen" prompt
3. Tap to install as native app

### Offline Support
- Home page cached
- Service catalog available offline
- Booking forms work (sync when online)
- Basic navigation functional

### Performance
- Lighthouse score: 95+ PWA
- First Contentful Paint: <1.5s
- Largest Contentful Paint: <2.5s
- Time to Interactive: <3s

## 📊 API Endpoints

### Public Endpoints
- `GET /config` - Get configuration
- `GET /services` - Get services list
- `GET /staff` - Get staff list
- `POST /bookings` - Create booking
- `GET /bookings?email=x` - Get customer bookings
- `POST /contact` - Submit contact form
- `GET /inventory` - Get product catalog

### Admin Endpoints
- `GET /admin/bookings` - All bookings
- `GET /admin/vaccinations` - All vaccinations
- `PUT /admin/inventory/:id` - Update inventory

## 🎨 UI Components

### Available Components
- Button, Input, Textarea, Select
- Card, Modal, Badge
- Header, Footer, Navigation
- Form validation with error handling
- Loading states and skeletons

### Design System
- **Primary Color**: Orange (#ed7e3f)
- **Secondary Color**: Green (#22c55e)
- **Typography**: Inter font
- **Spacing**: Tailwind CSS spacing scale
- **Responsive**: Mobile-first design

## 🔒 Security

### Implemented
- reCAPTCHA v3 protection
- Input validation (frontend + backend)
- XSS protection
- CSRF protection
- Secure headers (HSTS, CSP)

### Recommendations
- Use HTTPS in production
- Implement rate limiting
- Regular security audits
- Keep dependencies updated

## 📈 Performance

### Optimization Techniques
- Code splitting by route
- Image optimization
- Service worker caching
- Gzip compression
- Browser caching headers
- Minified CSS/JS

### Monitoring
- Google Analytics integration
- Lighthouse audits
- Core Web Vitals tracking
- Error logging in Google Sheets

## 🚀 Deployment

### Hostinger Deployment
1. Build the app: `npm run build`
2. Upload `dist/` contents to Hostinger
3. Configure `.htaccess` for routing
4. Setup SSL certificate
5. Test all functionality

### Domain Configuration
```apache
# .htaccess for SPA routing
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /index.html [QSA,L]
```

## 🧪 Testing

### Manual Testing Checklist
- [ ] All pages load correctly
- [ ] Mobile responsive design
- [ ] Booking form submission
- [ ] Email notifications
- [ ] PWA installation
- [ ] Offline functionality
- [ ] Cross-browser compatibility

### Automated Testing
```bash
# Run linting
npm run lint

# Type checking
npm run type-check

# Build test
npm run build
```

## 📚 Documentation

- [Deployment Guide](./docs/DEPLOY.md) - Step-by-step deployment
- [Admin Guide](./docs/ADMIN.md) - Backend management
- [API Documentation](./docs/API.md) - API reference (coming soon)
- [Component Library](./docs/COMPONENTS.md) - UI components (coming soon)

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

### Getting Help
- 📖 Check the [documentation](./docs/)
- 🐛 [Report issues](https://github.com/your-repo/issues)
- 💬 [Discussions](https://github.com/your-repo/discussions)

### Common Issues
- **API not working**: Check Google Apps Script deployment
- **PWA not installing**: Ensure HTTPS is enabled
- **Emails not sending**: Check Gmail quota and permissions
- **Build errors**: Verify Node.js version and dependencies

## 🎉 Acknowledgments

- Google for the amazing free services (Sheets, Apps Script, Gmail)
- The React and Vite teams for excellent developer tools
- Tailwind CSS for the utility-first CSS framework
- All the open source contributors who made this possible

---

**Built with ❤️ for pet lovers everywhere!**

🐾 **PawPaw Spa & Clinic** - Where pets get royal treatment!