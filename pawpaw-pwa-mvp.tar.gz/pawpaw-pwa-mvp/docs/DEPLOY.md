# PawPaw Spa & Clinic - Deployment Guide

## Overview
This guide will help you deploy the PawPaw PWA on Hostinger using Google services as the backend.

## Prerequisites
- Hostinger hosting account (Premium or Business plan recommended)
- Google Account (for Google Sheets, Apps Script, Gmail)
- Domain name (optional but recommended)

## Step 1: Setup Google Backend

### 1.1 Create Google Sheet
1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet named "PawPaw Spa & Clinic Database"
3. Copy the spreadsheet ID from the URL (e.g., `1ABC123XYZ...`)
4. Keep this sheet open for the next step

### 1.2 Setup Google Apps Script
1. Go to [Google Apps Script](https://script.google.com)
2. Click "New Project"
3. Replace the default code with the content from `backend/Code.gs`
4. Update the `CONFIG.SPREADSHEET_ID` with your sheet ID
5. Save the project (Ctrl+S)

### 1.3 Deploy as Web App
1. In Apps Script, click "Deploy" → "New Deployment"
2. Select "Web App" as the deployment type
3. Configure:
   - Description: "PawPaw API"
   - Execute as: "Me"
   - Who has access: "Anyone"
4. Click "Deploy"
5. Authorize the permissions when prompted
6. Copy the Web App URL (e.g., `https://script.google.com/macros/s/ABC123XYZ/exec`)

### 1.4 Initialize Spreadsheet
1. In the Apps Script editor, run the `setupSpreadsheet()` function
2. This will create all necessary sheets and sample data
3. Refresh your Google Sheet to see the created tabs

## Step 2: Configure Frontend

### 2.1 Update Environment Variables
1. Open the `app/.env` file
2. Replace `YOUR_WEB_APP_URL` with your Google Apps Script URL
3. Replace `YOUR_RECAPTCHA_SITE_KEY` with your reCAPTCHA site key

### 2.2 Setup reCAPTCHA (Optional but Recommended)
1. Go to [Google reCAPTCHA Admin Console](https://www.google.com/recaptcha/admin/create)
2. Register your site:
   - Label: "PawPaw Spa & Clinic"
   - reCAPTCHA type: "reCAPTCHA v3"
   - Domains: Add your domain (e.g., yourdomain.com)
3. Get the Site Key and Secret Key
4. Add Site Key to `.env` file
5. Add Secret Key to Google Sheet CONFIG tab

## Step 3: Build Frontend

### 3.1 Install Dependencies
```bash
cd app
npm install
```

### 3.2 Build for Production
```bash
npm run build
```

### 3.3 Test Locally
```bash
npm run preview
```

## Step 4: Deploy to Hostinger

### 4.1 Upload Files
1. Connect to your Hostinger hosting via FTP or File Manager
2. Navigate to your public HTML directory (usually `public_html`)
3. Upload the contents of `app/dist` folder
4. Ensure all files are uploaded, including:
   - `index.html`
   - `assets/` folder
   - `manifest.json` (will be generated)
   - `sw.js` (will be generated)

### 4.2 Configure .htaccess
Create a `.htaccess` file in your root directory with:
```apache
# Enable URL Rewriting
RewriteEngine On

# Handle React Router
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /index.html [QSA,L]

# Gzip Compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Cache Headers
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType image/png "access plus 1 month"
    ExpiresByType image/jpg "access plus 1 month"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/gif "access plus 1 month"
    ExpiresByType image/ico "access plus 1 month"
    ExpiresByType image/icon "access plus 1 month"
    ExpiresByType text/html "access plus 1 hour"
</IfModule>

# Security Headers
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://www.google.com https://www.gstatic.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https://script.google.com"
</IfModule>
```

### 4.3 Setup SSL Certificate
1. In Hostinger control panel, go to SSL
2. Enable free Let's Encrypt SSL certificate
3. Force HTTPS redirect

## Step 5: Test Deployment

### 5.1 Basic Functionality Test
1. Open your website in a browser
2. Test all pages load correctly
3. Test mobile responsiveness
4. Test booking form submission
5. Check email confirmations

### 5.2 PWA Features Test
1. Open Chrome DevTools → Application
2. Check Manifest is valid
3. Test Service Worker registration
4. Test offline functionality
5. Test "Add to Home Screen" on mobile

### 5.3 Lighthouse Test
1. Run Lighthouse audit in Chrome DevTools
2. Target: 95+ PWA score
3. Fix any issues found

## Step 6: Ongoing Maintenance

### 6.1 Updates
- Frontend: Rebuild and upload `dist` folder
- Backend: Update Apps Script code and redeploy
- Database: Manage directly in Google Sheets

### 6.2 Monitoring
- Check Google Sheet for new bookings
- Monitor email deliverability
- Check SSL certificate renewal

### 6.3 Backup
- Google Sheets: Auto-backed up by Google
- Frontend: Keep local copy of source code
- Apps Script: Version history available

## Troubleshooting

### Common Issues

**API Errors**
- Check Google Apps Script deployment permissions
- Verify spreadsheet ID is correct
- Check CORS headers in Apps Script

**PWA Not Installing**
- Verify manifest.json is accessible
- Check service worker registration
- Ensure site is served over HTTPS

**Email Not Sending**
- Check Gmail quota limits
- Verify Apps Script email permissions
- Check spam folder

**Booking Not Saving**
- Check Google Sheet permissions
- Verify API endpoint URL
- Check browser console for errors

### Support Resources
- Google Apps Script Documentation
- Hostinger Knowledge Base
- PWA Best Practices Guide

## Security Considerations

1. **API Security**: Consider implementing API keys for production
2. **Data Privacy**: Ensure GDPR compliance if applicable
3. **Rate Limiting**: Implement in Apps Script if needed
4. **Input Validation**: Already implemented in frontend and backend
5. **HTTPS**: Always use SSL in production

## Performance Optimization

1. **Images**: Compress and use WebP format
2. **Caching**: Configured in .htaccess
3. **CDN**: Consider using Cloudflare (free tier)
4. **Monitoring**: Use Google Analytics for insights

## Next Steps

1. Set up Google Analytics for traffic monitoring
2. Configure Facebook Pixel for marketing
3. Set up automated email reminders
4. Add online payment processing
5. Implement push notifications

---

**Deployment Complete! 🎉**

Your PawPaw Spa & Clinic PWA should now be live and ready to serve pets and their owners!