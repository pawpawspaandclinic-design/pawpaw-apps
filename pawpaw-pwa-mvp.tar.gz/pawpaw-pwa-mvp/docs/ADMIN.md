# PawPaw Spa & Clinic - Admin Guide

## Overview
This guide explains how to manage the PawPaw Spa & Clinic PWA using the admin features and Google Sheets backend.

## Accessing Admin Features

### Admin Dashboard Access
The admin features are accessible through the Google Sheets backend. There's no separate admin login - access is controlled through Google account permissions.

### Google Sheets Management
1. Open your "PawPaw Spa & Clinic Database" Google Sheet
2. You'll see the following tabs:
   - CONFIG
   - SERVICES
   - STAFF
   - BOOKINGS
   - VACCINATIONS
   - INVENTORY
   - EMAIL_TEMPLATES
   - PUSH_TOKENS
   - LOGS

## Managing Bookings

### View All Bookings
1. Go to the **BOOKINGS** sheet
2. All customer bookings are listed here
3. Columns include:
   - ID: Unique booking identifier
   - ServiceID: Service reference
   - StaffID: Staff member reference
   - CustomerName, CustomerEmail, CustomerPhone
   - PetName, PetType, PetBreed
   - Date, Time
   - Status: pending, confirmed, cancelled, completed
   - Notes, TotalPrice
   - CreatedAt, UpdatedAt

### Update Booking Status
1. Find the booking in the BOOKINGS sheet
2. Update the "Status" column:
   - `pending` → New booking
   - `confirmed` → Appointment confirmed
   - `cancelled` → Customer cancelled
   - `completed` → Service provided
3. The "UpdatedAt" column will update automatically

### Managing Calendar Events
- Calendar events are created automatically when bookings are made
- Check your Google Calendar for appointment blocks
- Modify events directly in Google Calendar if needed

## Managing Services

### Add New Service
1. Go to the **SERVICES** sheet
2. Add a new row with:
   - ID: Unique identifier (e.g., svc_005)
   - Name: Service name
   - Description: Service description
   - Duration: Duration in minutes
   - Price: Service price
   - Category: spa, clinic, grooming
   - Image: Image URL (optional)

### Update Service
1. Find the service in the SERVICES sheet
2. Update any fields as needed
3. Changes will reflect immediately in the app

### Remove Service
1. Find the service in the SERVICES sheet
2. Delete the entire row
3. **Warning**: This will remove the service from the app

## Managing Staff

### Add Staff Member
1. Go to the **STAFF** sheet
2. Add a new row with:
   - ID: Unique identifier (e.g., staff_004)
   - Name: Staff member name
   - Role: Job title
   - Avatar: Profile image URL (optional)
   - Specialties: Array of specialties (e.g., ["Grooming", "Styling"])
   - Available: true/false

### Update Staff Availability
1. Find the staff member in the STAFF sheet
2. Update the "Available" column:
   - `true` → Available for bookings
   - `false` → Not available (temporarily or permanently)

### Staff Specialties
Specialties should be formatted as a JSON array:
```json
["General Practice", "Surgery"]
["Grooming", "Styling"]
["Massage", "Bathing"]
```

## Managing Inventory

### Add Product
1. Go to the **INVENTORY** sheet
2. Add a new row with:
   - ID: Unique identifier (e.g., inv_004)
   - Name: Product name
   - Category: food, accessory, medicine, toy
   - Description: Product description
   - Price: Selling price
   - Stock: Current stock quantity
   - MinStock: Minimum stock level for alerts
   - Image: Product image URL (optional)
   - SKU: Product SKU
   - Brand: Brand name (optional)
   - Weight: Product weight (optional)
   - AgeRange: Suitable age range (optional)

### Update Stock Levels
1. Find the product in the INVENTORY sheet
2. Update the "Stock" column
3. The app will show stock status based on MinStock level

### Low Stock Alerts
Products with stock ≤ MinStock will show as "Low Stock" in the app
Monitor these regularly and reorder as needed

## Managing Vaccinations

### View Vaccination Records
1. Go to the **VACCINATIONS** sheet
2. All customer vaccination records are listed
3. Columns include pet details, vaccine types, due dates

### Reminder System
- The "ReminderSent" column tracks if reminders were sent
- Implement automated reminders using Apps Script triggers
- Manual reminders can be sent via email

## Configuration Management

### Business Information
1. Go to the **CONFIG** sheet
2. Update business details:
   - BUSINESS_NAME: Your business name
   - BUSINESS_EMAIL: Contact email
   - BUSINESS_PHONE: Contact phone
   - BUSINESS_ADDRESS: Physical address
   - CURRENCY: Currency code (USD, EUR, etc.)
   - TIMEZONE: Your timezone

### reCAPTCHA Configuration
1. Get reCAPTCHA v3 keys from Google reCAPTCHA Admin Console
2. Add to CONFIG sheet:
   - RECAPTCHA_SECRET_KEY: Secret key for server-side validation
3. Add site key to frontend .env file

## Email Templates

### Customizing Emails
1. Go to the **EMAIL_TEMPLATES** sheet
2. Create templates for:
   - Booking confirmations
   - Vaccination reminders
   - Appointment reminders
   - Promotional emails

### Template Variables
Use these variables in templates:
- `{{customerName}}`
- `{{petName}}`
- `{{serviceName}}`
- `{{appointmentDate}}`
- `{{appointmentTime}}`
- `{{businessName}}`

## Monitoring and Logs

### View System Logs
1. Go to the **LOGS** sheet
2. All API requests are logged here
3. Columns include:
   - Timestamp: Request time
   - Method: HTTP method (GET, POST, etc.)
   - Path: API endpoint
   - Params: Request parameters
   - PostData: Request body
   - Result: Response data
   - User: User who made the request

### Monitoring Usage
- Check logs regularly for errors
- Monitor booking patterns
- Track popular services
- Identify system issues

## Automated Tasks

### Setting Up Triggers
1. In Google Apps Script, go to "Triggers"
2. Add automated tasks:
   - Daily vaccination reminders
   - Weekly inventory reports
   - Monthly booking summaries

### Example: Daily Vaccination Reminders
```javascript
function sendDailyVaccinationReminders() {
  // Logic to check due vaccinations and send emails
  // Run this function daily using a time-based trigger
}
```

## Security Best Practices

### Access Control
1. Share Google Sheet with trusted staff only
2. Use "Viewer" access for read-only needs
3. Use "Editor" access for management tasks

### Data Protection
1. Regular backup of Google Sheet
2. Monitor for unauthorized access
3. Use strong passwords for Google accounts

### API Security
1. Consider implementing API keys
2. Monitor API usage in logs
3. Rate limit if needed

## Performance Optimization

### Spreadsheet Optimization
1. Keep data organized and clean
2. Remove old logs periodically
3. Use data validation for consistency

### Apps Script Optimization
1. Minimize API calls
2. Use batch operations
3. Implement caching where possible

## Troubleshooting

### Common Issues

**Bookings Not Appearing**
- Check BOOKINGS sheet for new entries
- Verify API endpoint is working
- Check browser console for errors

**Email Not Sending**
- Check Gmail quota limits
- Verify email configuration
- Check spam folders

**Calendar Events Not Creating**
- Verify calendar permissions
- Check Apps Script authorization
- Review calendar settings

**Inventory Not Updating**
- Check INVENTORY sheet permissions
- Verify API calls are successful
- Review data format

### Debugging Tools
1. Google Apps Script execution logs
2. Browser developer console
3. Network tab for API requests
4. Google Sheet revision history

## Advanced Features

### Custom Reports
1. Create pivot tables in Google Sheets
2. Use Google Data Studio for dashboards
3. Export data for external analysis

### Integrations
1. QuickBooks for accounting
2. Mailchimp for email marketing
3. Stripe for payments (future enhancement)

### Automation Ideas
1. Automatic follow-up emails
2. Inventory reordering alerts
3. Staff scheduling optimization
4. Customer satisfaction surveys

## Support and Training

### Staff Training
1. Train staff on Google Sheets usage
2. Create standard operating procedures
3. Provide documentation and guides

### Customer Support
1. Set up support email address
2. Create FAQ documentation
3. Provide phone support options

---

**Admin Guide Complete! 🎉**

You now have full control over your PawPaw Spa & Clinic PWA. Regular monitoring and updates will ensure smooth operation and excellent customer service.