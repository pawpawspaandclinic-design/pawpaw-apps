export interface Service {
  id: string;
  name: string;
  description: string;
  duration: number; // in minutes
  price: number;
  category: 'spa' | 'clinic' | 'grooming';
  image?: string;
}

export interface Staff {
  id: string;
  name: string;
  role: string;
  avatar?: string;
  specialties: string[];
  available: boolean;
}

export interface Booking {
  id: string;
  serviceId: string;
  staffId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  petName: string;
  petType: 'dog' | 'cat' | 'other';
  petBreed?: string;
  date: string; // ISO string
  time: string; // HH:MM format
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;
  totalPrice: number;
  createdAt: string;
  updatedAt: string;
}

export interface Vaccination {
  id: string;
  petName: string;
  petType: 'dog' | 'cat' | 'other';
  vaccineType: string;
  dueDate: string;
  lastAdministered?: string;
  nextDueDate: string;
  clinicName: string;
  notes?: string;
  reminderSent: boolean;
  customerId: string;
  customerEmail: string;
  customerPhone: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: 'food' | 'accessory' | 'medicine' | 'toy';
  description: string;
  price: number;
  stock: number;
  minStock: number;
  image?: string;
  sku: string;
  brand?: string;
  weight?: string;
  ageRange?: string;
}

export interface ContactForm {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  createdAt: string;
}

export interface TimeSlot {
  time: string;
  available: boolean;
  staffId: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface Config {
  businessName: string;
  businessEmail: string;
  businessPhone: string;
  businessAddress: string;
  workingHours: {
    [key: string]: { open: string; close: string; closed?: boolean };
  };
  bookingSettings: {
    minAdvanceHours: number;
    maxAdvanceDays: number;
    slotDuration: number;
  };
  recaptchaSiteKey: string;
  currency: string;
  timezone: string;
}