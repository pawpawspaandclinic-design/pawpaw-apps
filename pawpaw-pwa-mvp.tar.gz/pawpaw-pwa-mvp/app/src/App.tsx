import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Header, Footer } from './components/layout/Header';
import HomePage from './pages/HomePage';
import BookingPage from './pages/BookingPage';
import CatalogPage from './pages/CatalogPage';
import ContactPage from './pages/ContactPage';
import VaccinationsPage from './pages/VaccinationsPage';
import { useAppStore } from './store/appStore';
import { Button } from './components/ui/Button';
import { X, Download } from 'lucide-react';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

// PWA Install Prompt Component
const PWAInstallPrompt: React.FC = () => {
  const { installPrompt, isInstalled, setInstallPrompt } = useAppStore();
  const [showPrompt, setShowPrompt] = React.useState(false);

  useEffect(() => {
    // Show install prompt after 3 seconds if not installed and prompt is available
    if (!isInstalled && installPrompt && !localStorage.getItem('pwa-install-dismissed')) {
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [installPrompt, isInstalled]);

  const handleInstall = async () => {
    if (installPrompt) {
      installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      console.log(`User response to the install prompt: ${outcome}`);
      setInstallPrompt(null);
      setShowPrompt(false);
    }
  };

  const handleDismiss = () => {
    localStorage.setItem('pwa-install-dismissed', 'true');
    setShowPrompt(false);
  };

  if (!showPrompt || isInstalled || !installPrompt) {
    return null;
  }

  return (
    <div className="pwa-install-prompt">
      <div className="flex items-start space-x-3">
        <div className="bg-primary/10 p-2 rounded-lg">
          <Download className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-sm">Install PawPaw App</h4>
          <p className="text-xs text-gray-600 mt-1">
            Get the best experience with our mobile app
          </p>
          <div className="flex space-x-2 mt-3">
            <Button size="sm" onClick={handleInstall}>
              Install
            </Button>
            <Button size="sm" variant="ghost" onClick={handleDismiss}>
              Not now
            </Button>
          </div>
        </div>
        <button
          onClick={handleDismiss}
          className="text-gray-400 hover:text-gray-600"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

// App Content Component
const AppContent: React.FC = () => {
  const { setInstallPrompt, setIsInstalled } = useAppStore();

  useEffect(() => {
    // PWA Install Prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    // PWA Install Detection
    const handleAppInstalled = () => {
      setIsInstalled(true);
      localStorage.removeItem('pwa-install-dismissed');
    };

    // Service Worker Registration
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('SW registered: ', registration);
        })
        .catch((registrationError) => {
          console.log('SW registration failed: ', registrationError);
        });
    }

    // Check if app is installed
    const checkInstalled = () => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppiOS = (window.navigator as any).standalone === true;
      setIsInstalled(isStandalone || isInWebAppiOS);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    checkInstalled();

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [setInstallPrompt, setIsInstalled]);

  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/booking" element={<BookingPage />} />
            <Route path="/catalog" element={<CatalogPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/vaccinations" element={<VaccinationsPage />} />
          </Routes>
        </main>
        <Footer />
        <PWAInstallPrompt />
      </div>
    </Router>
  );
};

// Main App Component
const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
};

export default App;