import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Calendar, User, Check } from 'lucide-react';
import { useServices, useStaff, useCreateBooking } from '../hooks/api';
import { useAppStore } from '../store/appStore';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Input, Textarea, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { formatCurrency, generateTimeSlots } from '../lib/utils';

const bookingSchema = z.object({
  customerName: z.string().min(2, 'Name must be at least 2 characters'),
  customerEmail: z.string().email('Invalid email address'),
  customerPhone: z.string().min(10, 'Phone number must be at least 10 digits'),
  petName: z.string().min(1, 'Pet name is required'),
  petType: z.enum(['dog', 'cat', 'other']),
  petBreed: z.string().optional(),
  serviceId: z.string().min(1, 'Please select a service'),
  staffId: z.string().min(1, 'Please select a staff member'),
  date: z.string().min(1, 'Please select a date'),
  time: z.string().min(1, 'Please select a time'),
  notes: z.string().optional(),
});

type BookingFormData = z.infer<typeof bookingSchema>;

const BookingPage: React.FC = () => {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const { data: services = [], isLoading: servicesLoading } = useServices();
  const { data: staff = [], isLoading: staffLoading } = useStaff();
  const createBookingMutation = useCreateBooking();
  const { setCustomerInfo } = useAppStore();

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
  });

  const watchedServiceId = watch('serviceId');
  const watchedStaffId = watch('staffId');
  const watchedDate = watch('date');

  const selectedServiceData = (services as any[]).find((s: any) => s.id === watchedServiceId);

  // Generate time slots
  const timeSlots = watchedDate ? generateTimeSlots('09:00', '18:00', 30) : [];

  const onSubmit = async (data: BookingFormData) => {
    try {
      const bookingPayload = {
        ...data,
        totalPrice: selectedServiceData?.price || 0,
        status: 'pending' as const,
      };

      await createBookingMutation.mutateAsync(bookingPayload);
      
      // Save customer info
      setCustomerInfo({
        name: data.customerName,
        email: data.customerEmail,
        phone: data.customerPhone,
      });

      setShowSuccessModal(true);
    } catch (error) {
      console.error('Booking failed:', error);
    }
  };

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const maxDate = new Date();
  maxDate.setDate(maxDate.getDate() + 30);

  if (servicesLoading || staffLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Book an Appointment
          </h1>
          <p className="text-xl text-gray-600">
            Schedule the perfect pampering session for your furry friend
          </p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Calendar className="h-6 w-6 text-primary" />
              <h2 className="text-2xl font-semibold">Appointment Details</h2>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              {/* Service Selection */}
              <div>
                <h3 className="text-lg font-medium mb-4">Select Service</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(services as any[]).map((service: any) => (
                    <Card
                      key={service.id}
                      className={`cursor-pointer transition-all ${
                        watchedServiceId === service.id
                          ? 'ring-2 ring-primary bg-primary/5'
                          : 'hover:shadow-md'
                      }`}
                      onClick={() => setValue('serviceId', service.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-medium">{service.name}</h4>
                          <Badge variant="primary">{service.category}</Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{service.description}</p>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-500">{service.duration} min</span>
                          <span className="font-bold text-primary">
                            {formatCurrency(service.price)}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {errors.serviceId && (
                  <p className="text-red-600 text-sm mt-2">{errors.serviceId.message}</p>
                )}
              </div>

              {/* Staff Selection */}
              <div>
                <h3 className="text-lg font-medium mb-4">Choose Staff Member</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(staff as any[]).filter((s: any) => s.available).map((staffMember: any) => (
                    <Card
                      key={staffMember.id}
                      className={`cursor-pointer transition-all ${
                        watchedStaffId === staffMember.id
                          ? 'ring-2 ring-primary bg-primary/5'
                          : 'hover:shadow-md'
                      }`}
                      onClick={() => setValue('staffId', staffMember.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <div className="bg-primary/10 p-2 rounded-full">
                            <User className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium">{staffMember.name}</h4>
                            <p className="text-sm text-gray-600">{staffMember.role}</p>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {staffMember.specialties.slice(0, 2).map((specialty: any, index: number) => (
                                <Badge key={index} variant="outline" size="sm">
                                  {specialty}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                {errors.staffId && (
                  <p className="text-red-600 text-sm mt-2">{errors.staffId.message}</p>
                )}
              </div>

              {/* Date and Time */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input
                  label="Appointment Date"
                  type="date"
                  min={tomorrow.toISOString().split('T')[0]}
                  max={maxDate.toISOString().split('T')[0]}
                  {...register('date')}
                  error={errors.date?.message}
                />
                
                <Select
                  label="Preferred Time"
                  options={timeSlots.map(time => ({ value: time, label: time }))}
                  {...register('time')}
                  disabled={!watchedDate}
                  error={errors.time?.message}
                />
              </div>

              {/* Customer Information */}
              <div>
                <h3 className="text-lg font-medium mb-4">Your Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Your Name"
                    placeholder="John Doe"
                    {...register('customerName')}
                    error={errors.customerName?.message}
                  />
                  
                  <Input
                    label="Email Address"
                    type="email"
                    placeholder="john@example.com"
                    {...register('customerEmail')}
                    error={errors.customerEmail?.message}
                  />
                  
                  <Input
                    label="Phone Number"
                    type="tel"
                    placeholder="(555) 123-4567"
                    {...register('customerPhone')}
                    error={errors.customerPhone?.message}
                  />
                </div>
              </div>

              {/* Pet Information */}
              <div>
                <h3 className="text-lg font-medium mb-4">Pet Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Pet Name"
                    placeholder="Buddy"
                    {...register('petName')}
                    error={errors.petName?.message}
                  />
                  
                  <Select
                    label="Pet Type"
                    options={[
                      { value: 'dog', label: 'Dog' },
                      { value: 'cat', label: 'Cat' },
                      { value: 'other', label: 'Other' },
                    ]}
                    {...register('petType')}
                    error={errors.petType?.message}
                  />
                  
                  <Input
                    label="Breed (Optional)"
                    placeholder="Golden Retriever"
                    {...register('petBreed')}
                  />
                </div>
              </div>

              {/* Additional Notes */}
              <Textarea
                label="Additional Notes (Optional)"
                placeholder="Any special requirements or concerns..."
                rows={3}
                {...register('notes')}
              />

              {/* Price Summary */}
              {selectedServiceData && (
                <Card className="bg-gray-50">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-medium mb-4">Booking Summary</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Service:</span>
                        <span className="font-medium">{selectedServiceData.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span className="font-medium">{selectedServiceData.duration} minutes</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total Price:</span>
                        <span className="font-bold text-primary text-lg">
                          {formatCurrency(selectedServiceData.price)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Submit Button */}
              <div className="flex justify-center">
                <Button
                  type="submit"
                  size="lg"
                  loading={isSubmitting}
                  disabled={createBookingMutation.isPending}
                  className="px-8"
                >
                  {createBookingMutation.isPending ? 'Booking...' : 'Book Appointment'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Success Modal */}
        <Modal
          isOpen={showSuccessModal}
          onClose={() => setShowSuccessModal(false)}
          title="Appointment Booked Successfully!"
          size="md"
        >
          <div className="text-center">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Thank You!</h3>
            <p className="text-gray-600 mb-6">
              Your appointment has been booked successfully. We'll send a confirmation email shortly.
            </p>
            <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left">
              <h4 className="font-medium mb-2">Booking Details:</h4>
              <div className="space-y-1 text-sm">
                <p><strong>Service:</strong> {selectedServiceData?.name}</p>
                <p><strong>Date:</strong> {watchedDate}</p>
                <p><strong>Time:</strong> {watch('time')}</p>
                <p><strong>Pet:</strong> {watch('petName')}</p>
              </div>
            </div>
            <Button onClick={() => setShowSuccessModal(false)}>
              Close
            </Button>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default BookingPage;