import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Mail, Phone, MapPin, Clock, Send, Check } from 'lucide-react';
import { useSendContact } from '../hooks/api';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Input, Textarea, Select } from '../components/ui/Input';
import { Modal } from '../components/ui/Modal';

const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number must be at least 10 digits'),
  subject: z.string().min(1, 'Please select a subject'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

type ContactFormData = z.infer<typeof contactSchema>;

const ContactPage: React.FC = () => {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const sendContactMutation = useSendContact();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    try {
      await sendContactMutation.mutateAsync({
        ...data,
        createdAt: new Date().toISOString(),
      });
      
      reset();
      setShowSuccessModal(true);
    } catch (error) {
      console.error('Contact form submission failed:', error);
    }
  };

  const subjects = [
    { value: 'general', label: 'General Inquiry' },
    { value: 'booking', label: 'Booking Question' },
    { value: 'emergency', label: 'Emergency' },
    { value: 'feedback', label: 'Feedback' },
    { value: 'partnership', label: 'Partnership' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Get in Touch
          </h1>
          <p className="text-xl text-gray-600">
            We're here to help you and your furry friends
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Information */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <h3 className="text-xl font-semibold">Contact Information</h3>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-start space-x-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Phone className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Phone</h4>
                      <p className="text-gray-600">(555) 123-4567</p>
                      <p className="text-sm text-gray-500">Mon-Fri: 8AM-6PM</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Mail className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Email</h4>
                      <p className="text-gray-600">info@pawpawspa.com</p>
                      <p className="text-sm text-gray-500">24/7 Support</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <MapPin className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Address</h4>
                      <p className="text-gray-600">123 Pet Street</p>
                      <p className="text-gray-600">City, State 12345</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Hours</h4>
                      <p className="text-gray-600">Mon-Fri: 8AM-6PM</p>
                      <p className="text-gray-600">Saturday: 9AM-4PM</p>
                      <p className="text-gray-600">Sunday: Closed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Emergency Contact */}
              <Card className="border-red-200 bg-red-50">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-red-800 mb-2">
                    🚨 Emergency
                  </h3>
                  <p className="text-red-700 mb-3">
                    For pet emergencies, please call our emergency line:
                  </p>
                  <p className="text-xl font-bold text-red-800">
                    (555) 999-HELP
                  </p>
                  <p className="text-sm text-red-600 mt-2">
                    Available 24/7 for urgent cases
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <h3 className="text-xl font-semibold">Send us a Message</h3>
                <p className="text-gray-600">
                  Fill out the form below and we'll get back to you soon.
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input
                      label="Your Name"
                      placeholder="John Doe"
                      {...register('name')}
                      error={errors.name?.message}
                    />
                    
                    <Input
                      label="Email Address"
                      type="email"
                      placeholder="john@example.com"
                      {...register('email')}
                      error={errors.email?.message}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input
                      label="Phone Number"
                      type="tel"
                      placeholder="(555) 123-4567"
                      {...register('phone')}
                      error={errors.phone?.message}
                    />
                    
                    <Select
                      label="Subject"
                      options={subjects}
                      {...register('subject')}
                      error={errors.subject?.message}
                    />
                  </div>

                  <Textarea
                    label="Message"
                    placeholder="Tell us how we can help you and your pet..."
                    rows={6}
                    {...register('message')}
                    error={errors.message?.message}
                  />

                  <div className="flex justify-center">
                    <Button
                      type="submit"
                      size="lg"
                      loading={isSubmitting}
                      disabled={sendContactMutation.isPending}
                      className="px-8"
                    >
                      {sendContactMutation.isPending ? (
                        'Sending...'
                      ) : (
                        <>
                          Send Message
                          <Send className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* FAQ Section */}
            <Card className="mt-8">
              <CardHeader>
                <h3 className="text-xl font-semibold">Frequently Asked Questions</h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">How far in advance should I book?</h4>
                    <p className="text-gray-600">
                      We recommend booking at least 48 hours in advance, especially for weekend appointments.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Do you offer emergency services?</h4>
                    <p className="text-gray-600">
                      Yes, we have 24/7 emergency support. Call our emergency line for urgent cases.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">What payment methods do you accept?</h4>
                    <p className="text-gray-600">
                      We accept cash, credit cards, and mobile payment options.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Can I cancel or reschedule my appointment?</h4>
                    <p className="text-gray-600">
                      Yes, you can cancel or reschedule up to 24 hours before your appointment without any charges.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Success Modal */}
        <Modal
          isOpen={showSuccessModal}
          onClose={() => setShowSuccessModal(false)}
          title="Message Sent Successfully!"
          size="md"
        >
          <div className="text-center">
            <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Thank You!</h3>
            <p className="text-gray-600 mb-6">
              Your message has been sent successfully. We'll get back to you within 24 hours.
            </p>
            <Button onClick={() => setShowSuccessModal(false)}>
              Close
            </Button>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default ContactPage;