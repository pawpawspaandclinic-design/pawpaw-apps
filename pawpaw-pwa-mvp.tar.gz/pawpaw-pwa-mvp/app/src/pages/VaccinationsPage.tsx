import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  Syringe, 
  Calendar, 
  Plus, 
  Edit, 
  AlertCircle
} from 'lucide-react';
import { useVaccinations, useCreateVaccination, useUpdateVaccination } from '../hooks/api';
import { useAppStore } from '../store/appStore';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Input, Textarea, Select } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';
import { formatDate, isPast } from '../lib/utils';

const vaccinationSchema = z.object({
  petName: z.string().min(1, 'Pet name is required'),
  petType: z.enum(['dog', 'cat', 'other']),
  vaccineType: z.string().min(1, 'Vaccine type is required'),
  lastAdministered: z.string().optional(),
  nextDueDate: z.string().min(1, 'Next due date is required'),
  clinicName: z.string().min(1, 'Clinic name is required'),
  notes: z.string().optional(),
});

type VaccinationFormData = z.infer<typeof vaccinationSchema>;

const VaccinationsPage: React.FC = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingVaccination, setEditingVaccination] = useState<any>(null);
  const { customerInfo } = useAppStore();
  
  const { data: vaccinations = [], isLoading } = useVaccinations(customerInfo?.email || '');
  const createVaccinationMutation = useCreateVaccination();
  const updateVaccinationMutation = useUpdateVaccination();

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<VaccinationFormData>({
    resolver: zodResolver(vaccinationSchema),
  });

  const onSubmit = async (data: VaccinationFormData) => {
    try {
      const payload = {
        ...data,
        customerId: customerInfo?.email || '',
        customerEmail: customerInfo?.email || '',
        customerPhone: customerInfo?.phone || '',
        reminderSent: false,
      };

      if (editingVaccination) {
        await updateVaccinationMutation.mutateAsync({
          id: editingVaccination.id,
          vaccination: payload,
        });
      } else {
        await createVaccinationMutation.mutateAsync(payload);
      }

      reset();
      setShowAddModal(false);
      setEditingVaccination(null);
    } catch (error) {
      console.error('Vaccination operation failed:', error);
    }
  };

  const handleEdit = (vaccination: any) => {
    setEditingVaccination(vaccination);
    setValue('petName', vaccination.petName);
    setValue('petType', vaccination.petType);
    setValue('vaccineType', vaccination.vaccineType);
    setValue('lastAdministered', vaccination.lastAdministered || '');
    setValue('nextDueDate', vaccination.nextDueDate);
    setValue('clinicName', vaccination.clinicName);
    setValue('notes', vaccination.notes || '');
    setShowAddModal(true);
  };

  const getVaccinationStatus = (nextDueDate: string) => {
    const dueDate = new Date(nextDueDate);
    const today = new Date();
    const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (isPast(dueDate)) {
      return { status: 'overdue', color: 'danger', text: 'Overdue' };
    } else if (daysUntilDue <= 7) {
      return { status: 'due-soon', color: 'warning', text: `Due in ${daysUntilDue} days` };
    } else if (daysUntilDue <= 30) {
      return { status: 'upcoming', color: 'primary', text: `Due in ${daysUntilDue} days` };
    } else {
      return { status: 'scheduled', color: 'success', text: 'Scheduled' };
    }
  };

  const vaccineTypes = [
    { value: 'rabies', label: 'Rabies' },
    { value: 'dhpp', label: 'DHPP (Distemper, Hepatitis, Parainfluenza, Parvovirus)' },
    { value: 'bordetella', label: 'Bordetella (Kennel Cough)' },
    { value: 'feline-rhinotracheitis', label: 'Feline Rhinotracheitis' },
    { value: 'calicivirus', label: 'Calicivirus' },
    { value: 'panleukopenia', label: 'Panleukopenia' },
    { value: 'leptospirosis', label: 'Leptospirosis' },
    { value: 'lyme', label: 'Lyme Disease' },
    { value: 'other', label: 'Other' },
  ];

  if (!customerInfo) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <AlertCircle className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Sign In Required
          </h2>
          <p className="text-gray-600 mb-6">
            Please book an appointment first to access vaccination records.
          </p>
          <Button onClick={() => window.location.href = '/booking'}>
            Book Appointment
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Vaccination Records
            </h1>
            <p className="text-gray-600">
              Keep track of your pet's vaccination schedule
            </p>
          </div>
          <Button onClick={() => setShowAddModal(true)} className="mt-4 sm:mt-0">
            <Plus className="h-4 w-4 mr-2" />
            Add Vaccination
          </Button>
        </div>

        {/* Vaccinations List */}
        {(vaccinations as any[]).length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(vaccinations as any[]).map((vaccination: any) => {
              const status = getVaccinationStatus(vaccination.nextDueDate);
              
              return (
                <Card key={vaccination.id} className="card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="bg-primary/10 p-2 rounded-lg">
                          <Syringe className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">{vaccination.petName}</h3>
                          <p className="text-sm text-gray-500">{vaccination.petType}</p>
                        </div>
                      </div>
                      <Badge variant={status.color as any}>{status.text}</Badge>
                    </div>

                    <div className="space-y-3 mb-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Vaccine:</span>
                        <span className="font-medium">{vaccination.vaccineType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Clinic:</span>
                        <span className="font-medium">{vaccination.clinicName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Next Due:</span>
                        <span className="font-medium">{formatDate(vaccination.nextDueDate)}</span>
                      </div>
                      {vaccination.lastAdministered && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Last Given:</span>
                          <span className="font-medium">{formatDate(vaccination.lastAdministered)}</span>
                        </div>
                      )}
                    </div>

                    {vaccination.notes && (
                      <div className="bg-gray-50 rounded-lg p-3 mb-4">
                        <p className="text-sm text-gray-600">{vaccination.notes}</p>
                      </div>
                    )}

                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(vaccination)}
                        className="flex-1"
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      {status.status === 'due-soon' && (
                        <Button size="sm" className="flex-1">
                          <Calendar className="h-4 w-4 mr-1" />
                          Schedule
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Syringe className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No Vaccination Records
              </h3>
              <p className="text-gray-600 mb-6">
                Start tracking your pet's vaccinations by adding their first record.
              </p>
              <Button onClick={() => setShowAddModal(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add First Vaccination
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Add/Edit Modal */}
        <Modal
          isOpen={showAddModal}
          onClose={() => {
            setShowAddModal(false);
            setEditingVaccination(null);
            reset();
          }}
          title={editingVaccination ? 'Edit Vaccination' : 'Add Vaccination Record'}
          size="lg"
        >
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Pet Name"
                placeholder="Buddy"
                {...register('petName')}
                error={errors.petName?.message}
              />
              
              <Select
                label="Pet Type"
                options={[
                  { value: 'dog', label: 'Dog' },
                  { value: 'cat', label: 'Cat' },
                  { value: 'other', label: 'Other' },
                ]}
                {...register('petType')}
                error={errors.petType?.message}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select
                label="Vaccine Type"
                options={vaccineTypes}
                {...register('vaccineType')}
                error={errors.vaccineType?.message}
              />
              
              <Input
                label="Clinic Name"
                placeholder="City Vet Clinic"
                {...register('clinicName')}
                error={errors.clinicName?.message}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Last Administered (Optional)"
                type="date"
                {...register('lastAdministered')}
              />
              
              <Input
                label="Next Due Date"
                type="date"
                {...register('nextDueDate')}
                error={errors.nextDueDate?.message}
              />
            </div>

            <Textarea
              label="Additional Notes (Optional)"
              placeholder="Any reactions, special instructions..."
              rows={3}
              {...register('notes')}
            />

            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingVaccination(null);
                  reset();
                }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                loading={isSubmitting}
                disabled={createVaccinationMutation.isPending || updateVaccinationMutation.isPending}
              >
                {editingVaccination ? 'Update' : 'Add'} Vaccination
              </Button>
            </div>
          </form>
        </Modal>
      </div>
    </div>
  );
};

export default VaccinationsPage;