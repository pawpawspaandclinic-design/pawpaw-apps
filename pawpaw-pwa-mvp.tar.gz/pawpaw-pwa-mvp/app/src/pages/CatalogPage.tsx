import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ShoppingBag, 
  Heart, 
  Scissors, 
  Shield, 
  Star,
  Search
} from 'lucide-react';
import { useServices, useInventory } from '../hooks/api';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Input';
import { formatCurrency } from '../lib/utils';

const CatalogPage: React.FC = () => {
  const { data: services = [], isLoading: servicesLoading } = useServices();
  const { data: inventory = [], isLoading: inventoryLoading } = useInventory();
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState('all');

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'spa', label: 'Spa Services' },
    { value: 'clinic', label: 'Clinic Services' },
    { value: 'grooming', label: 'Grooming' },
    { value: 'food', label: 'Pet Food' },
    { value: 'accessory', label: 'Accessories' },
    { value: 'medicine', label: 'Medicine' },
    { value: 'toy', label: 'Toys' },
  ];

  // Filter services and inventory
  const filteredServices = (services as any[]).filter((service: any) => {
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredInventory = (inventory as any[]).filter((item: any) => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getServiceIcon = (category: string) => {
    switch (category) {
      case 'spa': return Heart;
      case 'clinic': return Shield;
      case 'grooming': return Scissors;
      default: return Star;
    }
  };

  const getInventoryIcon = (category: string) => {
    switch (category) {
      case 'food': return ShoppingBag;
      case 'accessory': return Star;
      case 'medicine': return Shield;
      case 'toy': return Heart;
      default: return ShoppingBag;
    }
  };

  if (servicesLoading || inventoryLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Services & Products
          </h1>
          <p className="text-xl text-gray-600">
            Everything your pet needs in one place
          </p>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search services and products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select
              options={categories}
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            />
          </div>
        </div>

        {/* Services Section */}
        {filteredServices.length > 0 && (
          <section className="mb-16">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Our Services</h2>
              <Badge variant="primary">{filteredServices.length} services</Badge>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredServices.map((service: any) => {
                const Icon = getServiceIcon(service.category);
                return (
                  <Card key={service.id} className="card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="bg-primary/10 p-3 rounded-lg">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                        <Badge variant="outline">{service.category}</Badge>
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{service.name}</h3>
                      <p className="text-gray-600 mb-4">{service.description}</p>
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-sm text-gray-500">{service.duration} minutes</span>
                        <span className="text-xl font-bold text-primary">
                          {formatCurrency(service.price)}
                        </span>
                      </div>
                      <Link to="/booking">
                        <Button className="w-full">Book Now</Button>
                      </Link>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        )}

        {/* Products Section */}
        {filteredInventory.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Pet Products</h2>
              <Badge variant="secondary">{filteredInventory.length} products</Badge>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredInventory.map((item: any) => {
                const Icon = getInventoryIcon(item.category);
                const stockStatus = item.stock > item.minStock ? 'in-stock' : 'low-stock';
                
                return (
                  <Card key={item.id} className="card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="bg-secondary/10 p-3 rounded-lg">
                          <Icon className="h-6 w-6 text-secondary" />
                        </div>
                        <Badge 
                          variant={stockStatus === 'in-stock' ? 'success' : 'warning'}
                          size="sm"
                        >
                          {stockStatus === 'in-stock' ? 'In Stock' : `Only ${item.stock} left`}
                        </Badge>
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{item.name}</h3>
                      <p className="text-gray-600 text-sm mb-4">{item.description}</p>
                      {item.brand && (
                        <p className="text-xs text-gray-500 mb-2">Brand: {item.brand}</p>
                      )}
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-xl font-bold text-primary">
                          {formatCurrency(item.price)}
                        </span>
                      </div>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        disabled={stockStatus === 'low-stock'}
                      >
                        {stockStatus === 'in-stock' ? 'Add to Cart' : 'Out of Stock'}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        )}

        {/* No Results */}
        {filteredServices.length === 0 && filteredInventory.length === 0 && (
          <div className="text-center py-16">
            <ShoppingBag className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              No results found
            </h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search or filter criteria
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CatalogPage;