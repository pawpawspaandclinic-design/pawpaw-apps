import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Calendar, 
  Syringe, 
  ShoppingBag, 
  Phone, 
  Menu, 
  X,
  PawPrint
} from 'lucide-react';
import { useAppStore } from '../../store/appStore';
import { Button } from '../ui/Button';

const navigation = [
  { name: 'Home', href: '/', icon: Home },
  { name: 'Book Appointment', href: '/booking', icon: Calendar },
  { name: 'Vaccinations', href: '/vaccinations', icon: Syringe },
  { name: 'Catalog', href: '/catalog', icon: ShoppingBag },
  { name: 'Contact', href: '/contact', icon: Phone },
];

export const Header: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { customerInfo } = useAppStore();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <PawPrint className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-gray-900">PawPaw</span>
            <span className="text-sm text-gray-500 hidden sm:inline">Spa & Clinic</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-primary bg-primary/10'
                      : 'text-gray-700 hover:text-primary hover:bg-gray-50'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* User Info */}
          <div className="hidden md:flex items-center space-x-4">
            {customerInfo ? (
              <div className="text-sm text-gray-600">
                Welcome, <span className="font-medium">{customerInfo.name}</span>
              </div>
            ) : (
              <Link to="/booking">
                <Button size="sm">Get Started</Button>
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-gray-700 hover:text-primary hover:bg-gray-50"
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.href;
              
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center space-x-3 px-3 py-2 rounded-md text-base font-medium transition-colors ${
                    isActive
                      ? 'text-primary bg-primary/10'
                      : 'text-gray-700 hover:text-primary hover:bg-gray-50'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
            
            {customerInfo && (
              <div className="px-3 py-2 text-sm text-gray-600 border-t border-gray-200 mt-2 pt-4">
                Welcome, <span className="font-medium">{customerInfo.name}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <PawPrint className="h-8 w-8 text-primary" />
              <span className="text-xl font-bold">PawPaw Spa & Clinic</span>
            </div>
            <p className="text-gray-300 mb-4">
              Your trusted partner for pet wellness and happiness. 
              Professional spa treatments and veterinary care in a loving environment.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                Facebook
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                Instagram
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                Twitter
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/booking" className="text-gray-300 hover:text-primary transition-colors">Book Appointment</Link></li>
              <li><Link to="/catalog" className="text-gray-300 hover:text-primary transition-colors">Our Services</Link></li>
              <li><Link to="/vaccinations" className="text-gray-300 hover:text-primary transition-colors">Vaccination Schedule</Link></li>
              <li><Link to="/contact" className="text-gray-300 hover:text-primary transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-gray-300">
              <li>📍 123 Pet Street, City, State 12345</li>
              <li>📞 (555) 123-4567</li>
              <li>📧 info@pawpawspa.com</li>
              <li>🕒 Mon-Fri: 8AM-6PM, Sat: 9AM-4PM</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 PawPaw Spa & Clinic. All rights reserved.</p>
          <p className="mt-2 text-sm">
            Made with ❤️ for our furry friends
          </p>
        </div>
      </div>
    </footer>
  );
};