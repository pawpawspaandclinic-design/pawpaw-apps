const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://script.google.com/macros/s/YOUR_WEB_APP_URL/exec';

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string = API_BASE_URL) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  async get<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: 'GET' });
  }

  async post<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async put<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async delete<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: 'DELETE' });
  }
}

export const apiClient = new ApiClient();

// API endpoints
export const api = {
  // Config
  getConfig: () => apiClient.get('/config'),
  
  // Services
  getServices: () => apiClient.get('/services'),
  getService: (id: string) => apiClient.get(`/services/${id}`),
  
  // Staff
  getStaff: () => apiClient.get('/staff'),
  getStaffAvailability: (staffId: string, date: string) => 
    apiClient.get(`/staff/${staffId}/availability?date=${date}`),
  
  // Bookings
  createBooking: (booking: any) => apiClient.post('/bookings', booking),
  getBookings: (email: string) => apiClient.get(`/bookings?email=${email}`),
  updateBooking: (id: string, booking: any) => apiClient.put(`/bookings/${id}`, booking),
  cancelBooking: (id: string) => apiClient.delete(`/bookings/${id}`),
  
  // Vaccinations
  getVaccinations: (email: string) => apiClient.get(`/vaccinations?email=${email}`),
  createVaccination: (vaccination: any) => apiClient.post('/vaccinations', vaccination),
  updateVaccination: (id: string, vaccination: any) => 
    apiClient.put(`/vaccinations/${id}`, vaccination),
  
  // Inventory
  getInventory: () => apiClient.get('/inventory'),
  getInventoryByCategory: (category: string) => 
    apiClient.get(`/inventory?category=${category}`),
  
  // Contact
  sendContact: (contact: any) => apiClient.post('/contact', contact),
  
  // Admin
  getAdminBookings: () => apiClient.get('/admin/bookings'),
  getAdminVaccinations: () => apiClient.get('/admin/vaccinations'),
  getAdminInventory: () => apiClient.get('/admin/inventory'),
  updateInventory: (id: string, item: any) => apiClient.put(`/admin/inventory/${id}`, item),
  
  // Recaptcha
  verifyRecaptcha: (token: string) => apiClient.post('/verify-recaptcha', { token }),
};

export default api;