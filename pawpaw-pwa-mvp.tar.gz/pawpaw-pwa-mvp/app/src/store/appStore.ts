import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AppState {
  // UI State
  sidebarOpen: boolean;
  theme: 'light' | 'dark' | 'system';
  
  // User data
  customerInfo: {
    name: string;
    email: string;
    phone: string;
  } | null;
  
  // PWA
  installPrompt: any | null;
  isInstalled: boolean;
  
  // Notifications
  notifications: Array<{
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    title: string;
    message: string;
    timestamp: number;
    read: boolean;
  }>;
  
  // Actions
  setSidebarOpen: (open: boolean) => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setCustomerInfo: (info: { name: string; email: string; phone: string }) => void;
  setInstallPrompt: (prompt: any) => void;
  setIsInstalled: (installed: boolean) => void;
  addNotification: (notification: {
    type: 'success' | 'error' | 'warning' | 'info';
    title: string;
    message: string;
  }) => void;
  removeNotification: (id: string) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Initial state
      sidebarOpen: false,
      theme: 'system',
      customerInfo: null,
      installPrompt: null,
      isInstalled: false,
      notifications: [],
      
      // Actions
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      
      setTheme: (theme) => set({ theme }),
      
      setCustomerInfo: (info) => set({ customerInfo: info }),
      
      setInstallPrompt: (prompt) => set({ installPrompt: prompt }),
      
      setIsInstalled: (installed) => set({ isInstalled: installed }),
      
      addNotification: (notification) => {
        const id = Math.random().toString(36).substr(2, 9);
        set((state) => ({
          notifications: [
            ...state.notifications,
            {
              ...notification,
              id,
              timestamp: Date.now(),
              read: false,
            },
          ],
        }));
      },
      
      removeNotification: (id) => {
        set((state) => ({
          notifications: state.notifications.filter((n) => n.id !== id),
        }));
      },
      
      markNotificationRead: (id) => {
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, read: true } : n
          ),
        }));
      },
      
      clearNotifications: () => set({ notifications: [] }),
    }),
    {
      name: 'pawpaw-app-storage',
      partialize: (state) => ({
        theme: state.theme,
        customerInfo: state.customerInfo,
        notifications: state.notifications.filter(n => !n.read).slice(0, 10),
      }),
    }
  )
);

// Selectors
export const useCustomerInfo = () => useAppStore((state) => state.customerInfo);
export const useNotifications = () => useAppStore((state) => state.notifications);
export const useUnreadNotifications = () => 
  useAppStore((state) => state.notifications.filter(n => !n.read));
export const usePWAInstall = () => 
  useAppStore((state) => ({
    installPrompt: state.installPrompt,
    isInstalled: state.isInstalled,
    setInstallPrompt: state.setInstallPrompt,
    setIsInstalled: state.setIsInstalled,
  }));