import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api';
import type { Booking, Vaccination, InventoryItem } from '../types';

// Config
export const useConfig = () => {
  return useQuery({
    queryKey: ['config'],
    queryFn: api.getConfig,
    staleTime: 1000 * 60 * 30, // 30 minutes
  });
};

// Services
export const useServices = () => {
  return useQuery({
    queryKey: ['services'],
    queryFn: api.getServices,
    staleTime: 1000 * 60 * 15, // 15 minutes
  });
};

export const useService = (id: string) => {
  return useQuery({
    queryKey: ['service', id],
    queryFn: () => api.getService(id),
    enabled: !!id,
  });
};

// Staff
export const useStaff = () => {
  return useQuery({
    queryKey: ['staff'],
    queryFn: api.getStaff,
    staleTime: 1000 * 60 * 15, // 15 minutes
  });
};

export const useStaffAvailability = (staffId: string, date: string) => {
  return useQuery({
    queryKey: ['staff-availability', staffId, date],
    queryFn: () => api.getStaffAvailability(staffId, date),
    enabled: !!staffId && !!date,
  });
};

// Bookings
export const useCreateBooking = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: api.createBooking,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
    },
  });
};

export const useBookings = (email: string) => {
  return useQuery({
    queryKey: ['bookings', email],
    queryFn: () => api.getBookings(email),
    enabled: !!email,
  });
};

export const useUpdateBooking = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ id, booking }: { id: string; booking: Partial<Booking> }) =>
      api.updateBooking(id, booking),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
    },
  });
};

export const useCancelBooking = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: api.cancelBooking,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
    },
  });
};

// Vaccinations
export const useVaccinations = (email: string) => {
  return useQuery({
    queryKey: ['vaccinations', email],
    queryFn: () => api.getVaccinations(email),
    enabled: !!email,
  });
};

export const useCreateVaccination = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: api.createVaccination,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vaccinations'] });
    },
  });
};

export const useUpdateVaccination = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ id, vaccination }: { id: string; vaccination: Partial<Vaccination> }) =>
      api.updateVaccination(id, vaccination),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['vaccinations'] });
    },
  });
};

// Inventory
export const useInventory = () => {
  return useQuery({
    queryKey: ['inventory'],
    queryFn: api.getInventory,
    staleTime: 1000 * 60 * 10, // 10 minutes
  });
};

export const useInventoryByCategory = (category: string) => {
  return useQuery({
    queryKey: ['inventory', category],
    queryFn: () => api.getInventoryByCategory(category),
    enabled: !!category,
  });
};

// Contact
export const useSendContact = () => {
  return useMutation({
    mutationFn: api.sendContact,
  });
};

// Admin hooks
export const useAdminBookings = () => {
  return useQuery({
    queryKey: ['admin', 'bookings'],
    queryFn: api.getAdminBookings,
  });
};

export const useAdminVaccinations = () => {
  return useQuery({
    queryKey: ['admin', 'vaccinations'],
    queryFn: api.getAdminVaccinations,
  });
};

export const useAdminInventory = () => {
  return useQuery({
    queryKey: ['admin', 'inventory'],
    queryFn: api.getAdminInventory,
  });
};

export const useUpdateInventory = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ id, item }: { id: string; item: Partial<InventoryItem> }) =>
      api.updateInventory(id, item),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory'] });
      queryClient.invalidateQueries({ queryKey: ['admin', 'inventory'] });
    },
  });
};